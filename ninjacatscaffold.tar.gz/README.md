# Ninja-Cat

Plateforme d'aide à la décision pour le trading (quant).

**Principe directeur :** le moteur Python est la **source unique de vérité** ;
les couches d'affichage ne font que *rendre*. Seuils **scale-free** centralisés
dans `Config` ; seul `tick_size` est par-symbole. Simplicité avant tout.

## Structure

```
.claude/agents/      Agents quant spécialisés (voir ci-dessous)
.mcp.json            Serveur MCP tradingview (affichage + vérification visuelle)
src/ninja_cat/
  config.py          Config centrale (tous les scalaires calibrables)
  schema.py          Schéma canonique : Trade, Bar, Side
tests/               pytest
requirements.txt
```

## Agents (`.claude/agents/`)

| Agent | Rôle |
|---|---|
| `quant-strategy-architect` | Idée/doctrine → spec déterministe (pas de code) |
| `quant-data-engineer` | Ingestion/normalisation flux, schéma canonique, parité live==replay |
| `quant-algo-implementer` | Spec → code Python (+ Rust/Numba si mesuré) + tests |
| `quant-backtest-validator` | Mesure l'edge : triple-barrier, meta-labeling, purged CV, anti-look-ahead |
| `quant-viz-verifier` | Pilote tradingview-mcp : rend, vérifie visuellement, auto-corrige le rendu |

Flux : architect → data-engineer → implementer → backtest-validator → viz-verifier.

## Affichage / vérification (tradingview-mcp)

L'agent `quant-viz-verifier` s'appuie sur
[tradingview-mcp](https://github.com/tradesdontlie/tradingview-mcp) pour afficher
les sorties du moteur sur le chart, les relire, et auto-corriger le rendu.
TradingView ne recalcule **jamais** la doctrine — il ne fait que rendre.

Pré-requis :
1. `git clone https://github.com/tradesdontlie/tradingview-mcp vendor/tradingview-mcp`
   puis `cd vendor/tradingview-mcp && npm install` (Node 18+).
2. Ajuste le chemin dans `.mcp.json` (`args`) si besoin.
3. Lance **TradingView Desktop** avec `--remote-debugging-port=9222`
   (abonnement TradingView requis, port local 9222).

## Setup (quant)

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate.bat
pip install -r requirements.txt
pytest
```
